  .-----------------------------------------.
  |  PROACTIVE COMPUTER SECURITY            |
  |    Week 6: Return oriented programming  |
  |      Exercises                          |
  '-----------------------------------------'

There are 4 intro-levels this week, which gradually introduces ROP. Afterwards
there are two proper ROP exercises; ropalicious and ropasaurusrex.

The program 'ropasaurusrex' was made by Plaid Parliament of Pwning, and
published during their pCTF in 2013.

The goal is to write an exploit for each program that will get code or command
execution.  You may start with either program;  on the one hand 'ropalicious' is
definitely the easiest, but on the other hand you can find a solution for
'ropasaurusrex' in this weeks reading material.
