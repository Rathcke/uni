/**
 * 
 */
package com.acertainmarket.utils;

/**
 * AuctionMarketMessageTag implements the messages supported in the AuctionMarket
 * 
 */
public enum AuctionMarketMessageTag {
	ADDITEMS, QUERYITEMS, BID, SWITCHEPOCH;
}
