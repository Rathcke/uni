x = [0, 0, 1, 1, 0];
y = [0, 1, 1, 0, 0];
x2 = [0.4, 0.6, 1.3, 1, 0.4];
y2 = [1, 0.6, 0.8, 1.6, 1];

hold all
title('Quadriliterals obtained from datasets X and Y');
plot(x, y);
plot(x2, y2);