load 'diatoms';

hold on
plot(diatoms(1, 1:2:end), diatoms(1, 2:2:end))
axis equal;
hold off