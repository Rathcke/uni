var x = 42;
var y = [for (x of 'abc') x];
var z = x;
