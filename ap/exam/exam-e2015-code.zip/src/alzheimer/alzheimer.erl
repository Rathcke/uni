-module(alzheimer).
-export([start/0, upsert/3, query/2]).


%%%=========================================================================
%%%  API
%%%=========================================================================

start() ->
    undefined.

query(_Aid, _Pred) ->
    undefined.

upsert(_Aid, _Id, _F) ->
    undefined.
