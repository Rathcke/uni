module SubsParser (
  ParseError(..),
  parseString,
  parseFile
) where


import SubsAst

data ParseError = ParseError String
                deriving (Show, Eq)

parseString :: String -> Either ParseError Program
parseString = undefined

parseFile :: FilePath -> IO (Either ParseError Program)
parseFile path = fmap parseString $ readFile path
