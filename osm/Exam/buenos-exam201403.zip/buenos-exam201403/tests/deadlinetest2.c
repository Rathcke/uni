#include "tests/lib.h"

int main(void)
{
  puts("0\n");
  return 0;
}
