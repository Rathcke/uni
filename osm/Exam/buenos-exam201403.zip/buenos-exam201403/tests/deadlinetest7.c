#include "tests/lib.h"

int main(void)
{
  puts("4000\n");
  return 0;
}
