#include "tests/lib.h"

int main(void)
{
  puts("22500\n");
  return 0;
}
