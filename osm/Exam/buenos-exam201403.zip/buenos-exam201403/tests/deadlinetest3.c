#include "tests/lib.h"

int main(void)
{
  puts("1000\n");
  return 0;
}
