#include "tests/lib.h"

int main(void)
{
  puts("15000\n");
  return 0;
}
