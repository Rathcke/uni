#include "tests/lib.h"

int main(void)
{
  puts("7500\n");
  return 0;
}
